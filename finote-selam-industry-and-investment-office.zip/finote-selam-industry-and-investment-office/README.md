# Finote Selam industry and Investment Office 

A Pen created on CodePen.

Original URL: [https://codepen.io/Worku-Alemayehu/pen/gbpXmOY](https://codepen.io/Worku-Alemayehu/pen/gbpXmOY).

